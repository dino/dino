#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.ApplicationModel.Store.Preview.InstallControl.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

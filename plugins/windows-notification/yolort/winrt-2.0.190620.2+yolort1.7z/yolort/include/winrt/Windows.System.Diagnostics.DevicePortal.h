#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.System.Diagnostics.DevicePortal.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

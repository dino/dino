// C++/WinRT v2.0.190620.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#ifndef WINRT_Windows_Phone_StartScreen_H
#define WINRT_Windows_Phone_StartScreen_H
#include "base.h"
static_assert(winrt::check_version(CPPWINRT_VERSION, "2.0.190620.2"), "Mismatched C++/WinRT headers.");
#include "impl/Windows.Foundation.2.h"
#include "impl/Windows.UI.Notifications.2.h"
#include "impl/Windows.Phone.StartScreen.2.h"
namespace winrt::impl
{
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::DisplayName(param::hstring const& value) const
    {
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->put_DisplayName(*(void**)(&value)));
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::DisplayName() const
    {
        void* value{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->get_DisplayName(&value));
        return hstring{ value, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::IsPinnedToStart() const
    {
        bool value;
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->get_IsPinnedToStart(&value));
        return value;
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::CreateAsync() const
    {
        void* operation{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->CreateAsync(&operation));
        return Windows::Foundation::IAsyncOperation<bool>{ operation, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::UpdateAsync() const
    {
        void* operation{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->UpdateAsync(&operation));
        return Windows::Foundation::IAsyncOperation<bool>{ operation, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTile<D>::DeleteAsync() const
    {
        void* operation{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTile)->DeleteAsync(&operation));
        return Windows::Foundation::IAsyncOperation<bool>{ operation, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::GetTileForSim2() const
    {
        void* result{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->GetTileForSim2(&result));
        return Windows::Phone::StartScreen::DualSimTile{ result, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::UpdateDisplayNameForSim1Async(param::hstring const& name) const
    {
        void* operation{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->UpdateDisplayNameForSim1Async(*(void**)(&name), &operation));
        return Windows::Foundation::IAsyncOperation<bool>{ operation, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateTileUpdaterForSim1() const
    {
        void* updater{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateTileUpdaterForSim1(&updater));
        return Windows::UI::Notifications::TileUpdater{ updater, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateTileUpdaterForSim2() const
    {
        void* updater{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateTileUpdaterForSim2(&updater));
        return Windows::UI::Notifications::TileUpdater{ updater, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateBadgeUpdaterForSim1() const
    {
        void* updater{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateBadgeUpdaterForSim1(&updater));
        return Windows::UI::Notifications::BadgeUpdater{ updater, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateBadgeUpdaterForSim2() const
    {
        void* updater{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateBadgeUpdaterForSim2(&updater));
        return Windows::UI::Notifications::BadgeUpdater{ updater, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateToastNotifierForSim1() const
    {
        void* notifier{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateToastNotifierForSim1(&notifier));
        return Windows::UI::Notifications::ToastNotifier{ notifier, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IDualSimTileStatics<D>::CreateToastNotifierForSim2() const
    {
        void* notifier{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IDualSimTileStatics)->CreateToastNotifierForSim2(&notifier));
        return Windows::UI::Notifications::ToastNotifier{ notifier, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Phone_StartScreen_IToastNotificationManagerStatics3<D>::CreateToastNotifierForSecondaryTile(param::hstring const& tileId) const
    {
        void* notifier{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Phone::StartScreen::IToastNotificationManagerStatics3)->CreateToastNotifierForSecondaryTile(*(void**)(&tileId), &notifier));
        return Windows::UI::Notifications::ToastNotifier{ notifier, take_ownership_from_abi };
    }
    template <typename D>
    struct produce<D, Windows::Phone::StartScreen::IDualSimTile> : produce_base<D, Windows::Phone::StartScreen::IDualSimTile>
    {
        int32_t __stdcall put_DisplayName(void* value) noexcept final try
        {
            typename D::abi_guard guard(this->shim());
            this->shim().DisplayName(*reinterpret_cast<hstring const*>(&value));
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall get_DisplayName(void** value) noexcept final try
        {
            clear_abi(value);
            typename D::abi_guard guard(this->shim());
            *value = detach_from<hstring>(this->shim().DisplayName());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall get_IsPinnedToStart(bool* value) noexcept final try
        {
            typename D::abi_guard guard(this->shim());
            *value = detach_from<bool>(this->shim().IsPinnedToStart());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateAsync(void** operation) noexcept final try
        {
            clear_abi(operation);
            typename D::abi_guard guard(this->shim());
            *operation = detach_from<Windows::Foundation::IAsyncOperation<bool>>(this->shim().CreateAsync());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall UpdateAsync(void** operation) noexcept final try
        {
            clear_abi(operation);
            typename D::abi_guard guard(this->shim());
            *operation = detach_from<Windows::Foundation::IAsyncOperation<bool>>(this->shim().UpdateAsync());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall DeleteAsync(void** operation) noexcept final try
        {
            clear_abi(operation);
            typename D::abi_guard guard(this->shim());
            *operation = detach_from<Windows::Foundation::IAsyncOperation<bool>>(this->shim().DeleteAsync());
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
    template <typename D>
    struct produce<D, Windows::Phone::StartScreen::IDualSimTileStatics> : produce_base<D, Windows::Phone::StartScreen::IDualSimTileStatics>
    {
        int32_t __stdcall GetTileForSim2(void** result) noexcept final try
        {
            clear_abi(result);
            typename D::abi_guard guard(this->shim());
            *result = detach_from<Windows::Phone::StartScreen::DualSimTile>(this->shim().GetTileForSim2());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall UpdateDisplayNameForSim1Async(void* name, void** operation) noexcept final try
        {
            clear_abi(operation);
            typename D::abi_guard guard(this->shim());
            *operation = detach_from<Windows::Foundation::IAsyncOperation<bool>>(this->shim().UpdateDisplayNameForSim1Async(*reinterpret_cast<hstring const*>(&name)));
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateTileUpdaterForSim1(void** updater) noexcept final try
        {
            clear_abi(updater);
            typename D::abi_guard guard(this->shim());
            *updater = detach_from<Windows::UI::Notifications::TileUpdater>(this->shim().CreateTileUpdaterForSim1());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateTileUpdaterForSim2(void** updater) noexcept final try
        {
            clear_abi(updater);
            typename D::abi_guard guard(this->shim());
            *updater = detach_from<Windows::UI::Notifications::TileUpdater>(this->shim().CreateTileUpdaterForSim2());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateBadgeUpdaterForSim1(void** updater) noexcept final try
        {
            clear_abi(updater);
            typename D::abi_guard guard(this->shim());
            *updater = detach_from<Windows::UI::Notifications::BadgeUpdater>(this->shim().CreateBadgeUpdaterForSim1());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateBadgeUpdaterForSim2(void** updater) noexcept final try
        {
            clear_abi(updater);
            typename D::abi_guard guard(this->shim());
            *updater = detach_from<Windows::UI::Notifications::BadgeUpdater>(this->shim().CreateBadgeUpdaterForSim2());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateToastNotifierForSim1(void** notifier) noexcept final try
        {
            clear_abi(notifier);
            typename D::abi_guard guard(this->shim());
            *notifier = detach_from<Windows::UI::Notifications::ToastNotifier>(this->shim().CreateToastNotifierForSim1());
            return 0;
        }
        catch (...) { return to_hresult(); }
        int32_t __stdcall CreateToastNotifierForSim2(void** notifier) noexcept final try
        {
            clear_abi(notifier);
            typename D::abi_guard guard(this->shim());
            *notifier = detach_from<Windows::UI::Notifications::ToastNotifier>(this->shim().CreateToastNotifierForSim2());
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
    template <typename D>
    struct produce<D, Windows::Phone::StartScreen::IToastNotificationManagerStatics3> : produce_base<D, Windows::Phone::StartScreen::IToastNotificationManagerStatics3>
    {
        int32_t __stdcall CreateToastNotifierForSecondaryTile(void* tileId, void** notifier) noexcept final try
        {
            clear_abi(notifier);
            typename D::abi_guard guard(this->shim());
            *notifier = detach_from<Windows::UI::Notifications::ToastNotifier>(this->shim().CreateToastNotifierForSecondaryTile(*reinterpret_cast<hstring const*>(&tileId)));
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
}
namespace winrt::Windows::Phone::StartScreen
{
    inline DualSimTile::DualSimTile() :
        DualSimTile(impl::call_factory<DualSimTile>([](auto&& f) { return f.template ActivateInstance<DualSimTile>(); }))
    {
    }
    inline auto DualSimTile::GetTileForSim2()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.GetTileForSim2(); });
    }
    inline auto DualSimTile::UpdateDisplayNameForSim1Async(param::hstring const& name)
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.UpdateDisplayNameForSim1Async(name); });
    }
    inline auto DualSimTile::CreateTileUpdaterForSim1()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateTileUpdaterForSim1(); });
    }
    inline auto DualSimTile::CreateTileUpdaterForSim2()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateTileUpdaterForSim2(); });
    }
    inline auto DualSimTile::CreateBadgeUpdaterForSim1()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateBadgeUpdaterForSim1(); });
    }
    inline auto DualSimTile::CreateBadgeUpdaterForSim2()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateBadgeUpdaterForSim2(); });
    }
    inline auto DualSimTile::CreateToastNotifierForSim1()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateToastNotifierForSim1(); });
    }
    inline auto DualSimTile::CreateToastNotifierForSim2()
    {
        return impl::call_factory<DualSimTile, Windows::Phone::StartScreen::IDualSimTileStatics>([&](auto&& f) { return f.CreateToastNotifierForSim2(); });
    }
}
namespace std
{
    template<> struct hash<winrt::Windows::Phone::StartScreen::IDualSimTile> : winrt::impl::hash_base<winrt::Windows::Phone::StartScreen::IDualSimTile> {};
    template<> struct hash<winrt::Windows::Phone::StartScreen::IDualSimTileStatics> : winrt::impl::hash_base<winrt::Windows::Phone::StartScreen::IDualSimTileStatics> {};
    template<> struct hash<winrt::Windows::Phone::StartScreen::IToastNotificationManagerStatics3> : winrt::impl::hash_base<winrt::Windows::Phone::StartScreen::IToastNotificationManagerStatics3> {};
    template<> struct hash<winrt::Windows::Phone::StartScreen::DualSimTile> : winrt::impl::hash_base<winrt::Windows::Phone::StartScreen::DualSimTile> {};
}
#endif

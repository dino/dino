// C++/WinRT v2.0.190620.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#ifndef WINRT_Windows_Data_Xml_Xsl_H
#define WINRT_Windows_Data_Xml_Xsl_H
#include "base.h"
static_assert(winrt::check_version(CPPWINRT_VERSION, "2.0.190620.2"), "Mismatched C++/WinRT headers.");
#include "impl/Windows.Data.Xml.Dom.2.h"
#include "impl/Windows.Data.Xml.Xsl.2.h"
namespace winrt::impl
{
    template <typename D> auto consume_Windows_Data_Xml_Xsl_IXsltProcessor<D>::TransformToString(Windows::Data::Xml::Dom::IXmlNode const& inputNode) const
    {
        void* output{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Data::Xml::Xsl::IXsltProcessor)->TransformToString(*(void**)(&inputNode), &output));
        return hstring{ output, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Data_Xml_Xsl_IXsltProcessor2<D>::TransformToDocument(Windows::Data::Xml::Dom::IXmlNode const& inputNode) const
    {
        void* output{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Data::Xml::Xsl::IXsltProcessor2)->TransformToDocument(*(void**)(&inputNode), &output));
        return Windows::Data::Xml::Dom::XmlDocument{ output, take_ownership_from_abi };
    }
    template <typename D> auto consume_Windows_Data_Xml_Xsl_IXsltProcessorFactory<D>::CreateInstance(Windows::Data::Xml::Dom::XmlDocument const& document) const
    {
        void* xsltProcessor{};
        check_hresult(WINRT_IMPL_SHIM(Windows::Data::Xml::Xsl::IXsltProcessorFactory)->CreateInstance(*(void**)(&document), &xsltProcessor));
        return Windows::Data::Xml::Xsl::XsltProcessor{ xsltProcessor, take_ownership_from_abi };
    }
    template <typename D>
    struct produce<D, Windows::Data::Xml::Xsl::IXsltProcessor> : produce_base<D, Windows::Data::Xml::Xsl::IXsltProcessor>
    {
        int32_t __stdcall TransformToString(void* inputNode, void** output) noexcept final try
        {
            clear_abi(output);
            typename D::abi_guard guard(this->shim());
            *output = detach_from<hstring>(this->shim().TransformToString(*reinterpret_cast<Windows::Data::Xml::Dom::IXmlNode const*>(&inputNode)));
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
    template <typename D>
    struct produce<D, Windows::Data::Xml::Xsl::IXsltProcessor2> : produce_base<D, Windows::Data::Xml::Xsl::IXsltProcessor2>
    {
        int32_t __stdcall TransformToDocument(void* inputNode, void** output) noexcept final try
        {
            clear_abi(output);
            typename D::abi_guard guard(this->shim());
            *output = detach_from<Windows::Data::Xml::Dom::XmlDocument>(this->shim().TransformToDocument(*reinterpret_cast<Windows::Data::Xml::Dom::IXmlNode const*>(&inputNode)));
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
    template <typename D>
    struct produce<D, Windows::Data::Xml::Xsl::IXsltProcessorFactory> : produce_base<D, Windows::Data::Xml::Xsl::IXsltProcessorFactory>
    {
        int32_t __stdcall CreateInstance(void* document, void** xsltProcessor) noexcept final try
        {
            clear_abi(xsltProcessor);
            typename D::abi_guard guard(this->shim());
            *xsltProcessor = detach_from<Windows::Data::Xml::Xsl::XsltProcessor>(this->shim().CreateInstance(*reinterpret_cast<Windows::Data::Xml::Dom::XmlDocument const*>(&document)));
            return 0;
        }
        catch (...) { return to_hresult(); }
    };
}
namespace winrt::Windows::Data::Xml::Xsl
{
    inline XsltProcessor::XsltProcessor(Windows::Data::Xml::Dom::XmlDocument const& document) :
        XsltProcessor(impl::call_factory<XsltProcessor, Windows::Data::Xml::Xsl::IXsltProcessorFactory>([&](auto&& f) { return f.CreateInstance(document); }))
    {
    }
}
namespace std
{
    template<> struct hash<winrt::Windows::Data::Xml::Xsl::IXsltProcessor> : winrt::impl::hash_base<winrt::Windows::Data::Xml::Xsl::IXsltProcessor> {};
    template<> struct hash<winrt::Windows::Data::Xml::Xsl::IXsltProcessor2> : winrt::impl::hash_base<winrt::Windows::Data::Xml::Xsl::IXsltProcessor2> {};
    template<> struct hash<winrt::Windows::Data::Xml::Xsl::IXsltProcessorFactory> : winrt::impl::hash_base<winrt::Windows::Data::Xml::Xsl::IXsltProcessorFactory> {};
    template<> struct hash<winrt::Windows::Data::Xml::Xsl::XsltProcessor> : winrt::impl::hash_base<winrt::Windows::Data::Xml::Xsl::XsltProcessor> {};
}
#endif

#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.ApplicationModel.Email.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

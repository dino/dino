#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Networking.Vpn.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

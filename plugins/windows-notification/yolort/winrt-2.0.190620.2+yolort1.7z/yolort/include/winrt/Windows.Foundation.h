#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Foundation.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Globalization.NumberFormatting.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

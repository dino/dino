#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

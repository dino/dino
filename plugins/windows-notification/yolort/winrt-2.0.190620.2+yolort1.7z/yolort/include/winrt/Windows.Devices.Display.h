#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Devices.Display.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.Devices.Perception.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

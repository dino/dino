#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.ApplicationModel.DataTransfer.DragDrop.Core.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL

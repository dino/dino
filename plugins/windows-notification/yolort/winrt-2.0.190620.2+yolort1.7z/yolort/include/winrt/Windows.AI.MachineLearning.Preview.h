#define HEADER_IMPL <winrt/yolort_impl/winrt/Windows.AI.MachineLearning.Preview.h>
#include <winrt/yolort_impl/yolo.ipp>
#undef HEADER_IMPL
